﻿using ProjetoVendas.Database;
using ProjetoVendas.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoVendas.View
{
    class Listar
    {
        public static void ListarCliente()
        {
            Console.WriteLine("LISTAR CLIENTE");
            foreach (var item in ClienteDAO.RetornarClientes())
            {
                Console.WriteLine(item);
                Console.WriteLine("________________");
            }
        }
        public static void ListarVendedor()
        {
            Console.WriteLine("LISTAR VENDEDOR");
            foreach (var item in VendedorDAO.RetornarVendedores())
            {
                Console.WriteLine(item);
                Console.WriteLine("________________");
            }
        }
        public static void ListarProduto()
        {
            Console.WriteLine("LISTAR PRODUTO");
            foreach (var item in ProdutoDAO.RetornarProduto())
            {
                Console.WriteLine(item);
                Console.WriteLine("________________");
            }
        }
        public static void ListarVendas(List<Venda> vendas)
        {
            double subtotal, totalVenda = 0, totalGeral = 0;
            Console.WriteLine("LISTAR VENDAS");
            foreach (Venda vendaCadastrada in vendas)
            {
                Console.WriteLine("Cliente: " + vendaCadastrada.Cliente.Nome);
                Console.WriteLine("Vendedor: " + vendaCadastrada.Vendedor.Nome);
                Console.WriteLine("Data: " + vendaCadastrada.DataVenda);
                Console.WriteLine("ITENS VENDA");
                totalVenda = 0;
                foreach (var itemCadastrado in vendaCadastrada.ItensVenda)
                {
                    Console.WriteLine("\tNome: " + itemCadastrado.Produto.Nome);
                    Console.WriteLine("\tQuantidade: " + itemCadastrado.Quantidade);
                    Console.WriteLine("\tPreço: " + itemCadastrado.Preco.ToString("C2"));
                    subtotal = itemCadastrado.Preco * itemCadastrado.Quantidade;
                    totalVenda += subtotal;
                    Console.WriteLine("\tSubtotal: " + subtotal.ToString("C2"));
                }
                Console.WriteLine("TOTAL VENDA: " + totalVenda.ToString("C2"));
                totalGeral += totalVenda;
            }
            Console.WriteLine("TOTAL GERAL: " + totalGeral.ToString("C2"));
        }
    }
}
