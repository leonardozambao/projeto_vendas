﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoVendas.Model
{
    class Venda
    {
        public Venda()
        {
            CriadoEm = DateTime.Now;
            ItensVenda = new List<ItemVenda>();
            Cliente = new Cliente();
            Vendedor = new Vendedor();
        }
        public Cliente Cliente { get; set; }
        public Vendedor Vendedor { get; set; }
        public List<ItemVenda> ItensVenda { get; set; }
        public DateTime DataVenda { get; set; }
        public DateTime CriadoEm { get; set; }

        /*public override string ToString()
        {
            return "CPF Cliente: " + Cliente.Cpf + "\nCPF Vendedor: " + Vendedor.Cpf + "\nProduto: " + Produto.Nome  "\nQuantidade comprada: " + QtdCompra + "\nHora da compra: " + DataVenda;
        }*/
    }
}
