﻿using ProjetoVendas.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoVendas.Database
{
    class Dados
    {
        public static void IniciarDados()
        {
            Cliente cliente = new Cliente
            {
                Nome = "Roman Reigns",
                Cpf = "11418205958",
                HoraCadastro = DateTime.Now
            };
            Vendedor vendedor = new Vendedor
            {
                Nome = "John Cena",
                Cpf= "11418205958",
                HoraCadastro = DateTime.Now
            };
            Produto produto = new Produto
            {
                Nome = "PC",
                Preco = 1.200,
                Qtd = 20
            };
            Cliente cliente2 = new Cliente
            {
                Nome = "Leonardo Zambão",
                Cpf = "12345678909",
                HoraCadastro = DateTime.Now
            };
            Vendedor vendedor2 = new Vendedor
            {
                Nome = "Brock Lesnar",
                Cpf = "12345678909",
                HoraCadastro = DateTime.Now
            };
            Produto produto2 = new Produto
            {
                Nome = "Celular",
                Preco = 2.100,
                Qtd = 10
            };

            ClienteDAO.CadastrarCliente(cliente);
            ClienteDAO.CadastrarCliente(cliente2);
            VendedorDAO.CadastrarVendedores(vendedor);
            VendedorDAO.CadastrarVendedores(vendedor2);
            ProdutoDAO.CadastrarProduto(produto);
            ProdutoDAO.CadastrarProduto(produto2);
        }
    }
}
