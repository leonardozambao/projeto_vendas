﻿using ProjetoVendas.Model;
using ProjetoVendas.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoVendas.Database
{
    class ProdutoDAO
    {
        private static List<Produto> produtos = new List<Produto>();

        public static void CadastrarProduto(Produto p)
        {
            produtos.Add(p);
        }
        public static List<Produto> RetornarProduto()
        {
            return produtos;
        }
        public static Produto RetornaProdutoPorNome(Produto p)
        {
            foreach (Produto item in produtos)
            {
                if (!ValidaProduto.UnicoProduto(p.Nome))
                {
                    return item;
                }
            }
            return null;
        }
    }
}
