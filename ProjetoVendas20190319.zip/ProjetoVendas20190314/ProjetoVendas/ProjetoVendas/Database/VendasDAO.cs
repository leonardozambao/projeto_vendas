﻿using ProjetoVendas.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoVendas.Database
{
    class VendasDAO
    {
        private static List<Venda> vendas = new List<Venda>();
        public static void CadastrarVenda(Venda v)
        {
            vendas.Add(v);
        }
        public static List<Venda> RetornarVenda()
        {
            return vendas;
        }

        public static List<Venda> BuscarVendasPorCpf(Cliente c)
        {
            List<Venda> aux = new List<Venda>();
            foreach (Venda item in vendas)
            {
                if (item.Cliente.Cpf.Equals(c.Cpf))
                {
                    aux.Add(item);
                }
            }
            return aux;
        }
        /*public static List<Venda> RetornarVendaPorCpf()
        {
        }*/
    }
}
