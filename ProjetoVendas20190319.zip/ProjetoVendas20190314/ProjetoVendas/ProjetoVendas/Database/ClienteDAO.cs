﻿using ProjetoVendas.Model;
using ProjetoVendas.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoVendas.Database
{
    class ClienteDAO
    {
        private static List<Cliente> clientes = new List<Cliente>();
        public static void CadastrarCliente(Cliente c)
        {
            clientes.Add(c);
        }
        public static List<Cliente> RetornarClientes()
        {
            return clientes;
        }
        public static Cliente RetornaClientePorCpf(Cliente c) {
            foreach (Cliente item in clientes)
            {
                if (!ValidaCpf.UnicoCliente(c.Cpf))
                {
                    return item;
                }
            }
            return null;
        }
    }
}
