﻿using ProjetoVendas.Database;
using ProjetoVendas.Model;
using ProjetoVendas.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoVendas.View
{
    class Cadastrar
    {
        public static void CadastrarCliente()
        {
            Console.WriteLine("CADASTRAR CLIENTE");
            Cliente c = new Cliente();
            Console.WriteLine("Informe o nome: ");
            c.Nome = Console.ReadLine();
            Console.WriteLine("Informe o CPF: ");
            c.Cpf = Console.ReadLine();

            if (!ValidaCpf.valida(c.Cpf))
            {
                Console.WriteLine("CPF INVÁLIDO!");
            }
            else
            {
                if (ValidaCpf.UnicoCliente(c.Cpf))
                {
                    ClienteDAO.CadastrarCliente(c);
                    Console.WriteLine("Cliente cadastrado com sucesso!");
                }
                else
                {
                    Console.WriteLine("Já existe um cliente com este CPF!");
                }
            }
        }
        public static void CadastrarVendedor()
        {

            Console.WriteLine("CADASTRAR VENDEDOR");
            Vendedor v = new Vendedor();
            Console.WriteLine("Informe o nome: ");
            v.Nome = Console.ReadLine();
            Console.WriteLine("Informe o CPF: ");
            v.Cpf = Console.ReadLine();

            if (!ValidaCpf.valida(v.Cpf))
            {
                Console.WriteLine("CPF INVÁLIDO!");
            }
            else
            {
                if (ValidaCpf.UnicoVendedor(v.Cpf))
                {
                    VendedorDAO.CadastrarVendedores(v);
                    Console.WriteLine("Vendedor cadastrado com sucesso!");
                }
                else
                {
                    Console.WriteLine("Já existe um cliente com este CPF!");
                }
            }
        }
        public static void CadastrarProduto()
        {
            Console.WriteLine("CADASTRAR PRODUTO");
            Produto p = new Produto();
            Console.WriteLine("Informe o nome: ");
            p.Nome = Console.ReadLine();

            if (ValidaProduto.UnicoProduto(p.Nome))
            {
                Console.WriteLine("Informe o preço: ");
                p.Preco = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Informe a quantidade: ");
                p.Qtd = Convert.ToInt32(Console.ReadLine());

                ProdutoDAO.CadastrarProduto(p);
                Console.WriteLine("Produto cadastrado com sucesso!");
            }
            else
            {
                Console.WriteLine("Já existe um produto com este Nome!");
            }
        }
        public static void RegistrarVenda()
        {
            Console.WriteLine("REGISTRAR VENDA!");
            Cliente c = new Cliente();
            Vendedor v = new Vendedor();
            Produto p = new Produto();
            Venda venda = new Venda();

            Console.WriteLine("INFORME O CPF DO CLIENTE:");
            c.Cpf = Console.ReadLine();
            c = ClienteDAO.RetornaClientePorCpf(c);
            if (c == null)
            {
                Console.WriteLine("cpf inválido");
            }
            else
            {
                Console.WriteLine("INFORME O CPF DO VENDEDOR:");
                v.Cpf = Console.ReadLine();
                v = VendedorDAO.RetornaVendedorPorCpf(v);
                if (v == null)
                {
                    Console.WriteLine("cpf inválido");
                }
                else
                {
                    Console.WriteLine("INFORME O NOME DO PRODUTO:");
                    p.Nome = Console.ReadLine();
                    p = ProdutoDAO.RetornaProdutoPorNome(p);
                    if (p == null)
                    {
                        Console.WriteLine("nome de produto inválido");
                    }
                    else
                    {
                        Console.WriteLine("INFORME A QUANTIDADE DO PRODUTO:");
                        p.Qtd = Convert.ToInt32(Console.ReadLine());
                        venda.DataVenda = DateTime.Now;

                        venda.Cliente = c;
                        venda.Vendedor = v;
                        venda.Produto = p;
                        venda.QtdCompra = p.Qtd;
                        VendasDAO.CadastrarVenda(venda);
                    }
                }
            }
        }
    }
}
