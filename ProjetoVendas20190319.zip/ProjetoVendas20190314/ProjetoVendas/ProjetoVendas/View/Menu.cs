﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoVendas.View
{
    class Menu
    {
        public static void Imprimir()
        {
            Console.WriteLine("\n***************************************");
            Console.WriteLine("1 - Cadastrar Cliente");
            Console.WriteLine("2 - Listar Clientes");
            Console.WriteLine("3 - Cadastrar Vendedor");
            Console.WriteLine("4 - Listar Vendedores");
            Console.WriteLine("5 - Cadastrar Produto");
            Console.WriteLine("6 - Listar Produtos");
            Console.WriteLine("7 - Registrar Venda");
            Console.WriteLine("8 - Listar Vendas");
            Console.WriteLine("9 - Listar Vendas por Cliente");
            Console.WriteLine("0 - Finalizar");
        }

        public static void Finalizar()
        {
            Console.WriteLine("***************************************");
            Console.WriteLine("Programa encerrado");
            Console.ReadKey();
        }
    }
}
