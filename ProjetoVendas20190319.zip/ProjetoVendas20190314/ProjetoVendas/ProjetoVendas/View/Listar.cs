﻿using ProjetoVendas.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoVendas.View
{
    class Listar
    {
        public static void ListarCliente()
        {
            Console.WriteLine("LISTAR CLIENTE");
            foreach (var item in ClienteDAO.RetornarClientes())
            {
                Console.WriteLine(item);
                Console.WriteLine("________________");
            }
        }
        public static void ListarVendedor()
        {
            Console.WriteLine("LISTAR VENDEDOR");
            foreach (var item in VendedorDAO.RetornarVendedores())
            {
                Console.WriteLine(item);
                Console.WriteLine("________________");
            }
        }
        public static void ListarProduto()
        {
            Console.WriteLine("LISTAR PRODUTO");
            foreach (var item in ProdutoDAO.RetornarProduto())
            {
                Console.WriteLine(item);
                Console.WriteLine("________________");
            }
        }
        public static void ListarVendas()
        {
            Console.WriteLine("LISTAR VENDAS");
            foreach (var item in VendasDAO.RetornarVenda())
            {
                Console.WriteLine(item);
                Console.WriteLine("________________");
            }
        }
        /*public static void ListarVendasPorCliente()
        {
            Console.WriteLine("LISTAR VENDAS");
            foreach (var item in VendasDAO.())
            {
                Console.WriteLine(item);
                Console.WriteLine("________________");
            }
        }*/
    }
}
