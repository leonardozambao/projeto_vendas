﻿using ProjetoVendas.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoVendas.Util
{
    class ValidaProduto
    {
        public static Boolean UnicoProduto(string nome)
        {
            Boolean nomeUnico = true;
            foreach (var item in ProdutoDAO.RetornarProduto())
            {
                if (nome.Equals(item.Nome, StringComparison.InvariantCultureIgnoreCase))
                {
                    nomeUnico = false;
                    break;
                }
            }
            if (!nomeUnico)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        /*public static Boolean QuantidadePermitida(string nome, int qtd)
        {
            foreach (var item in ProdutoDAO.RetornarProduto())
            {
                if (nome.Equals(item.Nome, StringComparison.InvariantCultureIgnoreCase))
                {
                    if (qtd > ProdutoDAO.RetornarProduto(qtd))
                }
            }
        }*/
    }
}
