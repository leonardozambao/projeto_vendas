﻿using ProjetoVendas.Database;
using ProjetoVendas.Model;
using ProjetoVendas.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoVendas.View
{
    class Cadastrar
    {
        public static void CadastrarCliente()
        {
            Console.WriteLine("CADASTRAR CLIENTE");
            Cliente c = new Cliente();
            Console.WriteLine("Informe o nome: ");
            c.Nome = Console.ReadLine();
            Console.WriteLine("Informe o CPF: ");
            c.Cpf = Console.ReadLine();

            if (ValidaCpf.UnicoCliente(c.Cpf))
            {
                ClienteDAO.CadastrarCliente(c);
                Console.WriteLine("Cliente cadastrado com sucesso!");
            }
            
        }
        public static void CadastrarVendedor()
        {

            Console.WriteLine("CADASTRAR VENDEDOR");
            Vendedor v = new Vendedor();
            Console.WriteLine("Informe o nome: ");
            v.Nome = Console.ReadLine();
            Console.WriteLine("Informe o CPF: ");
            v.Cpf = Console.ReadLine();

            if (ValidaCpf.UnicoVendedor(v.Cpf))
            {
                VendedorDAO.CadastrarVendedores(v);
                Console.WriteLine("Vendedor cadastrado com sucesso!");
            }
        }
        public static void CadastrarProduto()
        {
            Console.WriteLine("CADASTRAR PRODUTO");
            Produto p = new Produto();
            Console.WriteLine("Informe o nome: ");
            p.Nome = Console.ReadLine();

            if (ValidaProduto.UnicoProduto(p.Nome))
            {
                Console.WriteLine("Informe o preço: ");
                p.Preco = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Informe a quantidade: ");
                p.Qtd = Convert.ToInt32(Console.ReadLine());

                ProdutoDAO.CadastrarProduto(p);
                Console.WriteLine("Produto cadastrado com sucesso!");
            }
        }
    }
}
