﻿using ProjetoVendas.Model;
using ProjetoVendas.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoVendas.View
{
    class RegistroVenda
    {
        public static void RegistrarVenda()
        {
            Console.WriteLine("REGISTRAR VENDA!");
            Cliente c = new Cliente();
            Vendedor v = new Vendedor();
            Produto p = new Produto();
            Venda venda = new Venda();

            Console.WriteLine("INFORME O CPF DO CLIENTE:");
            c.Cpf = Console.ReadLine();
            if (ValidaCpf.UnicoCliente(c.Cpf))
            {
                Console.WriteLine("cpf de cliente inexistente:");
            }
            else
            {
                
            }

            Console.WriteLine("INFORME O CPF DO VENDEDOR:");
            Console.WriteLine("INFORME O NOME DO PRODUTO:");
            Console.WriteLine("INFORME A QUANTIDADE DE PRODUTO:");
        }
    }
}
