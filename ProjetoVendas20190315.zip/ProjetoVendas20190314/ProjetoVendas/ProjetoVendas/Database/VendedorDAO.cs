﻿using ProjetoVendas.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoVendas.Database
{
    class VendedorDAO
    {
        private static List<Vendedor> vendedores = new List<Vendedor>();
        public static void CadastrarVendedores(Vendedor v)
        {
            vendedores.Add(v);
        }
        public static List<Vendedor> RetornarVendedores()
        {
            return vendedores;
        }
    }
}
