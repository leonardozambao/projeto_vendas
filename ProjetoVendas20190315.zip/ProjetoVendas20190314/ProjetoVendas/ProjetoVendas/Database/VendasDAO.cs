﻿using ProjetoVendas.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoVendas.Database
{
    class VendasDAO
    {
        private static List<Venda> vendas = new List<Venda>();
        public static void CadastrarVenda(Venda v)
        {
            vendas.Add(v);
        }
        public static List<Venda> RetornarVenda()
        {
            return vendas;
        }
    }
}
