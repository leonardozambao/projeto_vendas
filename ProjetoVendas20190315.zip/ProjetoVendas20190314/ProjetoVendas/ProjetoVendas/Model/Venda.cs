﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoVendas.Model
{
    class Venda
    {
        public string CpfCliente { get; set; }
        public string CpfVendedor { get; set; }
        public string NomeProduto { get; set; }
        public int QtdCompra { get; set; }
    }
}
