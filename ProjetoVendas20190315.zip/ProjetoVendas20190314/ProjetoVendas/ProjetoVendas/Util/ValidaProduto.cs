﻿using ProjetoVendas.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoVendas.Util
{
    class ValidaProduto
    {
        public static Boolean UnicoProduto(string nome)
        {
            Boolean nomeUnico = true;
            foreach (var item in ProdutoDAO.RetornarProduto())
            {
                if (nome.Equals(item.Nome, StringComparison.InvariantCultureIgnoreCase))
                {
                    nomeUnico = false;
                    break;
                }
            }
            if (!nomeUnico)
            {
                Console.WriteLine("Já existe um produto com este Nome!");
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}
