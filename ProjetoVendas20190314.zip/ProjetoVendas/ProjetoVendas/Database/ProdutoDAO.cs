﻿using ProjetoVendas.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoVendas.Database
{
    class ProdutoDAO
    {
        private static List<Produto> produtos = new List<Produto>();
        public static void CadastrarProduto(Produto p)
        {
            produtos.Add(p);
        }
        public static List<Produto> RetornarProduto()
        {
            return produtos;
        }
    }
}
