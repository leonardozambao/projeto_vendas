﻿using ProjetoVendas.Database;
using ProjetoVendas.Model;
using ProjetoVendas.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoVendas.View
{
    class Cadastrar
    {
        public static void CadastrarCliente()
        {
            Boolean cpfUnico = true;
            Console.WriteLine("CADASTRAR CLIENTE");
            Cliente c = new Cliente();
            Console.WriteLine("Informe o nome: ");
            c.Nome = Console.ReadLine();
            Console.WriteLine("Informe o CPF: ");
            c.Cpf = Console.ReadLine();

            if (!ValidaCpf.valida(c.Cpf))
            {
                Console.WriteLine("CPF INVÁLIDO!");
            }
            else
            {
                foreach (var item in ClienteDAO.RetornarClientes())
                {
                    if (c.Cpf.Equals(item.Cpf))
                    {
                        cpfUnico = false;
                    }
                }
                if (cpfUnico)
                {
                    ClienteDAO.CadastrarCliente(c);
                    Console.WriteLine("Cliente cadastrado com sucesso!");
                }
                else
                {
                    Console.WriteLine("Já existe um cliente com este CPF!");
                }

            }
        }
        public static void CadastrarVendedor()
        {
            Boolean cpfUnico = true;
            Console.WriteLine("CADASTRAR VENDEDOR");
            Vendedor v = new Vendedor();
            Console.WriteLine("Informe o nome: ");
            v.Nome = Console.ReadLine();
            Console.WriteLine("Informe o CPF: ");
            v.Cpf = Console.ReadLine();

            if (!ValidaCpf.valida(v.Cpf))
            {
                Console.WriteLine("CPF INVÁLIDO!");
            }
            else
            {
                foreach (var item in VendedorDAO.RetornarVendedores())
                {
                    if (v.Cpf.Equals(item.Cpf))
                    {
                        cpfUnico = false;
                    }
                }
                if (cpfUnico)
                {
                    VendedorDAO.CadastrarVendedores(v);
                    Console.WriteLine("Vendedor cadastrado com sucesso!");
                }
                else
                {
                    Console.WriteLine("Já existe um vendedor com este CPF!");
                }

            }
        }
        public static void CadastrarProduto()
        {
            Boolean nomeUnico = true;
            Console.WriteLine("CADASTRAR PRODUTO");
            Produto p = new Produto();
            Console.WriteLine("Informe o nome: ");
            p.Nome = Console.ReadLine();
            foreach (var item in ProdutoDAO.RetornarProduto())
            {
                if (p.Nome.Equals(item.Nome))
                {
                    nomeUnico = false;
                }
            }
            if (!nomeUnico)
            {
                Console.WriteLine("Já existe um produto com este Nome!");
            }
            else
            {
                Console.WriteLine("Informe o preço: ");
                p.Preco = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Informe a quantidade: ");
                p.Qtd = Convert.ToInt32(Console.ReadLine());

                ProdutoDAO.CadastrarProduto(p);
                Console.WriteLine("Produto cadastrado com sucesso!");
            }
        }
    }
}
